INSERT INTO products (name, price) VALUES
('Product 1', 10.99),
('Product 2', 20.50),
('Product 3', 15.75);
