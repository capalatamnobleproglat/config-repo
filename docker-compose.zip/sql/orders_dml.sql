INSERT INTO orders (user_id, product_id, quantity, order_date) VALUES
(1, 1, 2, '2023-07-20'),
(1, 3, 1, '2023-07-21'),
(2, 2, 3, '2023-07-22');
